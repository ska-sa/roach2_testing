
/*
 * Additional urjtag cain operations. 
 * These are not language-binding specific, but do help in writing of concise
 * language bindings.  In theory, this code could someday be merged into 
 * the core urjtag library.
 *
 *
 * Copyright (C) 2011 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 */

#include <urjtag.h>
#include <chain.h>
#include <cmd.h>
#include <assert.h>
#include <string.h>
#include <sys/mman.h>

extern int      urj_cmd_test_cable (urj_chain_t * chain);
extern int      urj_cmd_params (char * const params[]);

int urj_chain_cable (urj_chain_t * chain, char *params[])
{
  urj_cable_t    *cable = NULL;
  int             i;
  int             j;
  int             paramc = urj_cmd_params (params);
  const urj_param_t **cable_params;
  urj_cable_parport_devtype_t devtype = -1;
  const char     *devname = NULL;
  int             param_start = 1;
  const urj_cable_driver_t *driver;

  /* search cable driver list */
  for (i = 0; urj_tap_cable_drivers[i]; i++)
    if (strcasecmp (params[0], urj_tap_cable_drivers[i]->name) == 0)
      break;
  driver = urj_tap_cable_drivers[i];
  if (!driver)
  {
    urj_error_set (URJ_ERROR_INVALID,
        "unknown cable driver '%s'", params[0]);
    return URJ_STATUS_FAIL;
  }

  if (driver->device_type == URJ_CABLE_DEVICE_PARPORT)
  {
    if (paramc < 4)
    {
      urj_error_set (URJ_ERROR_SYNTAX,
          "parallel cable requires >= 4 parameters");
      return URJ_STATUS_FAIL;
    }
    for (j = 0; j < URJ_CABLE_PARPORT_N_DEVS; j++)
      if (strcasecmp (params[1],
            urj_cable_parport_devtype_string (j)) == 0)
        break;
    if (j == URJ_CABLE_PARPORT_N_DEVS)
    {
      urj_error_set (URJ_ERROR_INVALID,
          "unknown parallel port device type '%s'",
          params[1]);
      return URJ_STATUS_FAIL;
    }

    devtype = j;
    devname = params[2];
    param_start = 3;
  }

  urj_param_init (&cable_params);
  for (j = param_start; params[j] != NULL; j++)
    if (urj_param_push (&urj_cable_param_list, &cable_params,
          params[j]) != URJ_STATUS_OK)
    {
      urj_param_clear (&cable_params);
      return URJ_STATUS_FAIL;
    }

  switch (driver->device_type)
  {
    case URJ_CABLE_DEVICE_PARPORT:
      cable =
        urj_tap_cable_parport_connect (chain, driver, devtype, devname,
            cable_params);
      break;
    case URJ_CABLE_DEVICE_USB:
      cable = urj_tap_cable_usb_connect (chain, driver, cable_params);
      break;
    case URJ_CABLE_DEVICE_OTHER:
      cable = urj_tap_cable_other_connect (chain, driver, cable_params);
      break;
  }

  urj_param_clear (&cable_params);

  if (cable == NULL)
  {
    return URJ_STATUS_FAIL;
  }

  chain->cable->chain = chain;
  return URJ_STATUS_OK;
}

int urj_initbus (urj_chain_t *chain, char *params[])
{
  int drv, i;
  const urj_param_t **bus_params;

  if (urj_cmd_test_cable (chain) != URJ_STATUS_OK)
    return URJ_STATUS_FAIL;

  if (urj_tap_chain_active_part (chain) == NULL)
    return URJ_STATUS_FAIL;

  for (drv = 0; urj_bus_drivers[drv] != NULL; drv++)
    if (strcasecmp (urj_bus_drivers[drv]->name, params[0]) == 0)
      break;

  if (urj_bus_drivers[drv] == NULL)
  {
    urj_error_set (URJ_ERROR_NOTFOUND, "Unknown bus: %s", params[0]);
    return URJ_STATUS_FAIL;
  }

  urj_param_init (&bus_params);
  for (i = 1; params[i] != NULL; i++)
    if (urj_param_push (&urj_bus_param_list, &bus_params,
          params[i]) != URJ_STATUS_OK)
    {
      urj_param_clear (&bus_params);
      return URJ_STATUS_FAIL;
    }

  if (urj_bus_init_bus(chain, urj_bus_drivers[drv], bus_params) == NULL)
  {
    urj_param_clear (&bus_params);
    return URJ_STATUS_FAIL;
  }

  urj_param_clear (&bus_params);
  return URJ_STATUS_OK;
}
