# python extension setup script for urjtag 

from distutils.core import setup, Extension
setup(name="urjtag", 
      version="1.0",
      description="urJtag Python Bindings",
      ext_modules=[
        Extension("urjtag", ["chain.c", "urj_helpers.c"],
                  include_dirs=['../../include/urjtag'],
                  library_dirs=['../../src/.libs'],
                  libraries=['urjtag'])
         ])
